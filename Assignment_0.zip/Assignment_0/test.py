# from vi import Agent, Simulation

# (
#     Simulation()
#     .batch_spawn_agents(500, Agent, images=["images/white.png"])
#     .run()
# )

from pygame import Vector2

print(Vector2(1, 2) / 2)
